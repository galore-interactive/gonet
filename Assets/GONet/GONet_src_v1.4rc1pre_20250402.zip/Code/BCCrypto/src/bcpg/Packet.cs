namespace Org.BouncyCastle.Bcpg
{
    public class Packet
        //: PacketTag
    {
    }
}
